<?php

class ConversionController extends TestCase {

    private $input;

    public function setUp() {
        parent::setUp();
        $this->input = "tests/files/unittestin.pdf";
    }

    /**
     * Test the constructor
     * @return [type] [description]
     */
    public function testConvert() {
      
    }

   

}
