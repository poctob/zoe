<?php namespace Zoe\Commands;

abstract class Command {

	//

}
