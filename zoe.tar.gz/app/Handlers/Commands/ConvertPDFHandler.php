<?php namespace Zoe\Handlers\Commands;

use Zoe\Commands\ConvertPDF;

use Illuminate\Queue\InteractsWithQueue;

class ConvertPDFHandler {

        
	/**
	 * Create the command handler.
	 *
	 * @return void
	 */
	public function __construct()
	{
		//
	}

	/**
	 * Handle the command.
	 *
	 * @param  ConvertPDF  $command
	 * @return void
	 */
	public function handle(ConvertPDF $command){

	}

}
