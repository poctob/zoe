<?php namespace Zoe\Events;

abstract class Event {

	//

}
