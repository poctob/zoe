<?php namespace Zoe\Http\Controllers;


use Laravel\Cashier\WebhookController as BaseController;

class StripeWebHookController extends BaseController {

	

}
