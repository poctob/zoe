<?php

namespace Zoe\Lib\PDF2DF;

/**
 * Description of Progress
 *
 * @author Alex Pavlunenko <alexp@xpresstek.net>
 */
class Progress implements iProgress{
    public function setCurrent($current) {
        
    }

    public function setMax($max) {
        
    }

//put your code here
}
